package com.example.cognify;

public class RegisterAdminActivity {
}
