package com.example.cognifyjavafiles;

public class RegisterAdminActivity {
}
