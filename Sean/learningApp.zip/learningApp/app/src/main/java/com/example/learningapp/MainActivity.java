package com.example.learningapp;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.example.learningapp.databinding.ActivityMainBinding;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    // A list to hold all our custom nav buttons for easy state management
    private List<View> navButtons = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupClickListeners();
        loadUserData();
    }

    /**
     * Sets up click listeners for all interactive UI elements.
     */
    private void setupClickListeners() {
        binding.ivProfilePicture.setOnClickListener(v -> showToast("Profile clicked"));
        binding.ivBellIcon.setOnClickListener(v -> showToast("Notifications clicked"));
        binding.ivMenuIcon.setOnClickListener(v -> showToast("Menu clicked"));

        // Call the new method to set up the custom navigation bar
        setupCustomBottomNav();
    }

    /**
     * Configures the custom bottom navigation bar by setting up each item individually.
     */
    private void setupCustomBottomNav() {
        // Add each nav item view to our list
        navButtons.add(binding.bottomNavigation.navHome);
        navButtons.add(binding.bottomNavigation.navBooks);
        navButtons.add(binding.bottomNavigation.navProfile);
        navButtons.add(binding.bottomNavigation.navGames);
        navButtons.add(binding.bottomNavigation.navSettings);

        // Set properties for each nav item
        setupNavItem(binding.bottomNavigation.navHome, R.drawable.ic_home, "Home");
        setupNavItem(binding.bottomNavigation.navBooks, R.drawable.ic_book, "Books");
        setupNavItem(binding.bottomNavigation.navProfile, R.drawable.ic_profile, "Profile");
        setupNavItem(binding.bottomNavigation.navGames, R.drawable.ic_games, "Games");
        setupNavItem(binding.bottomNavigation.navSettings, R.drawable.ic_settings, "Settings");

        // Set the "Home" button as active by default when the app starts
        updateNavSelection(binding.bottomNavigation.navHome);
    }

    /**
     * Helper method to configure a single navigation button's icon, text, and click listener.
     */
    private void setupNavItem(View navItemView, int iconResId, String title) {
        ImageView icon = navItemView.findViewById(R.id.iv_nav_icon);
        TextView text = navItemView.findViewById(R.id.tv_nav_title);

        icon.setImageResource(iconResId);
        text.setText(title);

        // Set the click listener to update the selection
        navItemView.setOnClickListener(v -> {
            updateNavSelection(v);
            showToast(title + " clicked");
            // TODO: Add logic here to switch Fragments or Activities
        });
    }

    /**
     * Handles the visual state change for all navigation buttons.
     * @param selectedButton The button that was just clicked.
     */
    private void updateNavSelection(View selectedButton) {
        for (View button : navButtons) {
            ImageView icon = button.findViewById(R.id.iv_nav_icon);
            ImageView background = button.findViewById(R.id.iv_nav_background);
            TextView text = button.findViewById(R.id.tv_nav_title);

            boolean isActive = (button == selectedButton);

            background.setVisibility(isActive ? View.VISIBLE : View.INVISIBLE);
            int color = ContextCompat.getColor(this, isActive ? R.color.primary_orange : R.color.gray_text);
            icon.setColorFilter(color, PorterDuff.Mode.SRC_IN);
            text.setTextColor(color);
        }
    }

    /**
     * Loads placeholder user data into the views.
     */
    private void loadUserData() {
        binding.tvName.setText("Kimberly");
        binding.tvStreakCount.setText("11");
    }

    /**
     * A helper method to quickly show a toast message.
     */
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}